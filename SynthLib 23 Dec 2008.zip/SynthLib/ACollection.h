//
//  Collection.h
//  SynthLib
//
//  Created by Andrew Hughes on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface ACollection : NSObject 
{
	NSMutableArray * theCollection;
	NSTableView * tableView;
	NSNumberFormatter *numberFormatter;

	NSMutableArray * hiddenCollection;	
	id activeSynthForFilter;
}

- (id) initForTableView:(NSTableView*) tb;

- (void) addItem: (id) newItem;
- (void) addItemAtSelectedRow: (id) newItem;
- (void) addItems: (NSArray*) newItems;

- (id) getItem: (int) i;
- (void) setTableView: (NSTableView*) tb;

- (NSMutableArray*) theCollection;

// Used by table view data source to change item properties.  Returns true if successful (result used by undo manager to decide whether to set and undo event)
- (BOOL) setValueForIdentifier: (NSString*) identifier row: (int) rowIndex objectValue: (id) anObject;

// Used by table view data source to retrieve item properties
- (NSString *) stringForIdentifier: (NSString*) identifier row: (int) rowIndex;
- (int) numberOfItems;

- (void) insertItem: (id) newItem atIndex: (int) index;
- (void) insertItems: (NSArray*) newItems atIndex: (int) i;
- (void) removeItems: (NSArray*) itemsToRemove;

- (int) indexOfItem: (id) item;

- (void) setSynthFilterForTableView: (id) activeSynth;
- (void) updateFilteredCollection;

@end
