//
//  ASynth.m
//  SynthLib
//
//  Created by Andrew Hughes on 11/24/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "ASynth.h"


@implementation ASynth

- (id)initWithInputPort: (int) _inputPort outputPort: (int) _outputPort
{

	if ((self = [super init]))
	{

		midi = nil;

		inputPort = _inputPort;
		outputPort = _outputPort;
		
		requestingCollection = nil;
		
		NSLog(@"inputPort = %d, outputPort = %d", inputPort, outputPort);
		
		NSAssert(inputPort >= 0 && outputPort >= 0, @"ASynth - Invalid input or output port (less than zero)!");
		
		deviceID = 0;
	}
	return self;
	
}

- (void) dealloc
{
	[midi release];
	[super dealloc];
}

- (void) encodeWithCoder: (NSCoder *) coder
{
	[coder encodeInt: inputPort forKey:@"inputPort"];
	[coder encodeInt: outputPort forKey:@"outputPort"];
	return;
}

- (id)initWithCoder: (NSCoder *) coder
{
	inputPort = [coder decodeIntForKey:@"inputPort"];
	outputPort = [coder decodeIntForKey:@"outputPort"];	

	deviceID = 0;

	return self;
}

// Create the Midi object
- (BOOL)createMidi
{
	midi = [[Midi alloc] initWithInputPort: inputPort outputPort: outputPort deviceID: deviceID synth: self];
	
	if (midi != nil) return TRUE;
	else return FALSE;
}


- (NSComparisonResult) compare: (ASynth*) aSynth
{
	return [[self name] compare:[aSynth name]];
}



@end
