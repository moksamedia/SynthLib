//
//  YamahaPCM91Program.h
//  SynthLib
//
//  Created by Andrew Hughes on 12/18/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "YamahaPCM91.h"
#import "AProgram.h"

@interface YamahaPCM91Program : AProgram {

}
- (void) writeByteToData: (Byte) byte atIndex: (int) index;
- (Byte) getByteFromData: (int) index;
- (void) writeBytesToData: (NSRange) range data: (NSData*) dataToWrite;
- (NSMutableData*) getBytesFromDataForRange: (NSRange) range;

@end
