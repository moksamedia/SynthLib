//
//  YamahaPCM91.h
//  SynthLib
//
//  Created by Andrew Hughes on 12/18/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ASynth.h"
#import "AProgram.h"
#import "YamahaPCM91Program.h"

enum 
{
	PCM91_NUMBER_OF_BANKS = 11,
	PCM91_NUM_PROGRAMS_PER_BANK = 50
};

enum
{
	PCM91_PROGRAM_NAME_OFFSET			= 5,
	PCM91_PROGRAM_NAME_LENGTH			= 12
};

enum
{
	PCM91_USER_BANK_1					= 9,
	PCM91_USER_BANK_2					= 10
};


@interface YamahaPCM91 : ASynth 
{

}

// called by the associated midi object when a complete sysex message is received
- (int) receiveSysexMessage: (NSMutableData *) data;
- (int) tryImportData: (NSMutableData*) dataToImport forCollection: (ACollection*) collection;

// Sysex data request methods
- (void) requestProgramDump: (int) programNumber bankNumber: (int) bankNumber forCollection: (ACollection*) collection;
- (void) requestProgramEditBufferDumpForCollection: (ACollection*) collection;
- (void) requestProgramBankDump: (int) bankNumber forCollection: (ACollection*) collection;

- (void) sendProgramDump: (AProgram*) program programNumber: (int) programNumber bankNumber: (int) bankNumber;
- (void) sendProgramDumpToEditBuffer: (AProgram*) program;
- (NSData*) prepareProgramToSend: (AProgram*) program programNumber: (int) programNumber bankNumber: (int) bankNumber;

@end
