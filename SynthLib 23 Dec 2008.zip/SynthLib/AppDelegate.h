//
//  AppDelegate.h
//  StoryWriter
//
//  Created by Andrew Hughes on 12/30/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

// Used to stop application from opening an untitled document on load

@interface AppDelegate : NSObject {

}

- (void)applicationWillTerminate:(NSNotification *)aNotification;
@end
