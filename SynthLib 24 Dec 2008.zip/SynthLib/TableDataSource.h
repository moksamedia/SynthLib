//
//  TableDataSource.h
//  SynthLib
//
//  Created by Andrew Hughes on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface TableDataSource : NSObject 
{
	id document;
}

- (id) initWithDocument: (id) _document;

// gets the display values from the data model
- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex;

// number of rows in the table view, number of items in the data model
- (int)numberOfRowsInTableView:(NSTableView *)aTableView;

// sets a new value for a given column and row, or a given property for an item
- (void)tableView:(NSTableView *)aTableView setObjectValue:anObject forTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex;

// sort functions
- (void)tableView:(NSTableView *)aTableView sortDescriptorsDidChange:(NSArray *)oldDescriptors;

- (void)sortUsingSameDescriptorForTableView:(NSTableView*) aTableView; // called when something is added or changed to update sort state



// DRAG AND DROP

// write rows to drag to pasteboard (I use my own pasteboard in Utility class)
- (BOOL)tableView:(NSTableView *)tv writeRowsWithIndexes:(NSIndexSet *)rowIndexes toPasteboard:(NSPasteboard*)pboard;

// validate proposed drop
- (NSDragOperation)tableView:(NSTableView*)tv validateDrop:(id <NSDraggingInfo>)info proposedRow:(int)row proposedDropOperation:(NSTableViewDropOperation)op;

// make drop
- (BOOL)tableView:(NSTableView *)aTableView acceptDrop:(id <NSDraggingInfo>)info row:(int)row dropOperation:(NSTableViewDropOperation)operation;

@end
