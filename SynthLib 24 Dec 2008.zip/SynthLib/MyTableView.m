//
//  MyTableView.m
//  SynthLib
//
//  Created by Andrew Hughes on 12/23/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "MyTableView.h"


@implementation MyTableView

+ (NSMenu *)defaultMenu 
{
    NSMenu *theMenu = [[[NSMenu alloc] initWithTitle:@"Contextual Menu"] autorelease];
    [theMenu insertItemWithTitle:@"Edit Multiple Selection" action:@selector(editMultipleSelection:) keyEquivalent:@"" atIndex:0];
    return theMenu;
}


- (NSMenu *)menuForEvent:(NSEvent *)theEvent {
      return [[self class] defaultMenu];
}


@end
