//
//  AlesisAndromeda.h
//  SynthLib
//
//  Created by Andrew Hughes on 11/25/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "SynthLib.h"
#import "ASynth.h"
#import "AProgram.h"

enum
{
	ANDROMEDA_USER_BANK		=	0,
	ANDROMEDA_PRESET1_BANK	=	1,
	ANDROMEDA_PRESET2_BANK	=	2
};


@interface AlesisAndromeda : ASynth {

}
// called by the associated midi object when a complete sysex message is received
- (int) receiveSysexMessage: (NSMutableData *) data;
- (int) tryImportData: (NSMutableData*) dataToImport forCollection: (ACollection*) collection;

// Sysex data request methods
- (void)requestProgramDump: (int) programNumber bankNumber: (int) bankNumber forCollection: (ACollection*) collection;
- (void)requestProgramEditBufferDump: (int) bufferNumber forCollection: (ACollection*) collection;
- (void)requestProgramBankDump: (int) bankNumber forCollection: (ACollection*) collection;
- (void)requestMixDump: (int) mixNumber bankNumber: (int) bankNumber forCollection: (ACollection*) collection;
- (void)requestMixEditBufferDumpForCollection: (ACollection*) collection;
- (void)requestMixBankDump: (int) bankNumber forCollection: (ACollection*) collection;
- (void)requestGlobalDataDumpForCollection: (ACollection*) collection;
- (void)requestAllDumpForCollection: (ACollection*) collection;

- (void) sendProgramDump: (AProgram*) program programNumber: (int) programNumber bankNumber: (int) bankNumber;

- (NSData*) prepareProgramToSend: (AProgram*) program programNumber: (int) programNumber bankNumber: (int) bankNumber;

@end
