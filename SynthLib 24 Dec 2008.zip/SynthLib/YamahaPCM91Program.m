//
//  YamahaPCM91Program.m
//  SynthLib
//
//  Created by Andrew Hughes on 12/18/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "YamahaPCM91Program.h"


@implementation YamahaPCM91Program



//////////////////////////////////////////////////////////////////////////////////////////////////
// GET AND SET PROGRAM PROPERTIES

- (NSString*) synthName
{
	return @"Yamaha PCM91";
}

- (int) bankNumber
{
	return bankNumber;
}

- (BOOL) setBankNumber: (int) i
{
	NSAssert(i >= 0 && i < PCM91_NUMBER_OF_BANKS, @"YamahaPCM91Program: setBankNumber - invalid bank number!");
	bankNumber = i;
	return TRUE;
}
- (BOOL) trySetBankNumber: (int) i
{
	if (i>=0 && i < PCM91_NUMBER_OF_BANKS)
	{
		[self setBankNumber: i];
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

- (NSString*) bankName
{
	switch (bankNumber) {
		case 0:
			return @"P0 - Halls";
			break;
		case 1:
			return @"P1 - Rooms";
			break;
		case 2:
			return @"P2 - Plates";
			break;
		case 3:
			return @"P3 - Post";
			break;
		case 4:
			return @"P4 - Splits";
			break;
		case 5:
			return @"P5 - Studio";
			break;
		case 6:
			return @"P6 - Live";
			break;
		case 7:
			return @"P7 - Post";
			break;
		case 8:
			return @"P8 - Surround";
			break;
		case 9:
			return @"R0 - User 1";
			break;
		case 10:
			return @"R1 - User 2";
			break;
		default:
			return @"DOH!";
			break;
	}
}

- (int) programNumber
{
	return programNumber;
}


- (BOOL) setProgramNumber: (int) i
{ 
	NSAssert(i>=0 && i < PCM91_NUM_PROGRAMS_PER_BANK, @"YamahaPCM91: setProgramNumber - invalid program number!");
	programNumber = i;
	return TRUE;
}

- (BOOL) trySetProgramNumber: (int) i
{
	if (i>=0 && i < PCM91_NUM_PROGRAMS_PER_BANK)
	{
		[self setProgramNumber: i];
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

- (NSString*) name
{
	// get an NSData from the main data with the name in it
	NSData * nameData = [self getBytesFromDataForRange: NSMakeRange(PCM91_PROGRAM_NAME_OFFSET, PCM91_PROGRAM_NAME_LENGTH)];

	[nameData retain];
	
	// convert nameData to string
	NSString * aName = [[NSString alloc] initWithBytes: [nameData bytes]  length: PCM91_PROGRAM_NAME_LENGTH encoding: NSASCIIStringEncoding];

	[nameData release];

	return aName;
}

- (BOOL) setName: (NSString*) newName
{	
	NSMutableData * nameData = [[newName dataUsingEncoding: NSASCIIStringEncoding allowLossyConversion: TRUE] mutableCopy];
	NSLog(@"New Name: %@", newName);
	
	[nameData setLength: PCM91_PROGRAM_NAME_LENGTH];
	
	[self writeBytesToData:NSMakeRange(PCM91_PROGRAM_NAME_OFFSET, PCM91_PROGRAM_NAME_LENGTH) data: nameData];
	return TRUE;
}

- (void) setData: (NSMutableData*) newData
{
	if (data!=nil) [data release];
	data = newData;
	[data retain];
}

- (void) sendToSynthAtProgramNumber: (int) pn bankNumber: (int) bn;
{
	if (pn = nil) pn = programNumber;
	if (bn = nil) bn = bankNumber;
	
	NSAssert(pn <= 50 && ( bn == PCM91_USER_BANK_1 || bn == PCM91_USER_BANK_2 ), @"Trying to send to improper program number or bank number!");
	
	[synth sendProgramDump: self programNumber:pn bankNumber: bn];
}


- (id) copy
{
	return [self copyWithZone:nil];
}

- (id) copyWithZone: (NSZone*) zone
{
	if (zone != nil)
	{
		return [[YamahaPCM91Program allocWithZone:zone] initWithSynth: synth data: [data mutableCopy] type: PROGRAM];
	}
	else
	{
		return [[YamahaPCM91Program alloc:NSDefaultMallocZone] initWithSynth: synth data: [data mutableCopy] type: PROGRAM];	
	}
}

- (id) mutableCopy
{
	return [self copyWithZone:nil];
}

- (id) mutableCopyWithZone: (NSZone*) zone
{
	return [self copyWithZone:zone];

}

- (NSMutableData*) getBytesFromDataForRange: (NSRange) range
{
	int index = range.location;
	int length = range.length;
	int i;
	
	NSMutableData * unpackedData = [[NSMutableData alloc] initWithLength:length];
	Byte * unpackedBytes = [unpackedData mutableBytes];
	
	for (i=0; i < length; i++)
	{
		unpackedBytes[i] = [self getByteFromData: i + index];
	}
	
	[unpackedData autorelease];
	
	return unpackedData;
}

- (void) writeBytesToData: (NSRange) range data: (NSData*) dataToWrite
{
	int index = range.location;
	int length = range.length;
	int i;
	
	Byte * unpackedBytes = (Byte*)[dataToWrite bytes];
	
	for (i=0; i < length; i++)
	{
		[self writeByteToData: unpackedBytes[i] atIndex: i + index];
	}


}

// reads a byte from packed data and unpacks it
- (Byte) getByteFromData: (int) index
{
	NSAssert(index < [data length] && index >= 0, @"YamahaPCM91Program: getByteFromData, index out of range!");
	unsigned char * packedBytes = (unsigned char*) [data bytes];  //packed
	Byte unpackedByte = 0x0;
	
	index = index * 2;
	
	unpackedByte = packedBytes[index] | ( packedBytes[index+1] << 4);
	
	//NSLog(@"Byte %d = %d - %c", index, unpackedByte, unpackedByte);
	
	return unpackedByte;
}

// writes a byte of unpacked data to packed data
- (void) writeByteToData: (Byte) byte atIndex: (int) index
{
	NSLog(@"Writing %X to index %d", byte, index);
	
	// needed to translate between nibble-ized index and unpacked index (bc there are two bytes of packed (nibble-ized) data per unpacked data
	index = index * 2;
	
	NSAssert(index < [data length] && index >= 0, @"YamahaPCM91Program: getByteFromData, index out of range!");
	unsigned char * packedBytes = [data mutableBytes];  //packed

	// clear the appropriate bits
	packedBytes[index]    = 0x00;
	packedBytes[index+1]  = 0x00;

	// set the LSB
	packedBytes[index]    = byte & 0x0F;  // 0x0F = 0000 1111
	
	// set the MSB
	packedBytes[index+1]  = byte >> 4;

}



@end
