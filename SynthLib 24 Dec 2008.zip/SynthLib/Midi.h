//
//  Midi.h
//  SynthLib
//
//  Created by Andrew Hughes on 11/23/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CoreMidi/MidiServices.h>

typedef struct PendingPacketList {
    void *readProcRefCon;
    void *srcConnRefCon;
    MIDIPacketList packetList;
} PendingPacketList;

bool sysexInProgressFlag;

@interface Midi : NSObject {

	int inputPort;
	int outputPort;
	int deviceID;
	id synth;
	
	BOOL connected;


	MIDIClientRef MIDIClient;
	MIDIPortRef MIDIInPort;
	MIDIPortRef MIDIOutPort;
	MIDIEndpointRef MIDIInputEndPoint;
	MIDIEndpointRef MIDIOutputEndPoint;
	
	NSMutableData * incomingData;  // buffer that holds the incoming packets as they are accrued until F7 is received
								   // once the complete message is received, the midi object sends the data to the requesting synth object
	
}

// Create a midi object for a given port and device ID configureation
// in and out port passed in here are 1-indexed (ie, port 1 is port 1 and NOT port 0)
- (id)initWithInputPort: (int) _inputPort outputPort: (int) _outputPort deviceID: (int) _deviceID synth: (id) _synth;

// request a dump from synth - this clears the incoming buffer prior to sending request
- (void) sendSysexRequest: (Byte*) shortSysex size: (int) size;
- (void) prepareForIncomingSysex;

// send short and long sysex messages
-(void)sendShortSysex: (Byte*) shortSysex size: (int) size;
-(void)sendLongSysex: (Byte*) longSysex size: (int) size;


@end
