//
//  MyTableView.h
//  SynthLib
//
//  Created by Andrew Hughes on 12/23/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MyTableView : NSTableView {

}

@end
