//
//  ACollectionItem.m
//  SynthLib
//
//  Created by Andrew Hughes on 12/20/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "ACollectionItem.h"


@implementation ACollectionItem
- (id) initWithSynth: (ASynth*) _synth data: (NSMutableData *) _data type: (int) _type
{
	if ((self = [super init])) 
	{
		synth = _synth;  // the synth object is not retained by the program, but by the document itself
		data = _data;
		[data retain];
		comments = [[NSString alloc] initWithString:@"-"];
		type = _type;  //item type, ie. Program, Bank, Global Dump, etc..

		name = [[NSString alloc] init];
		
	}
	return self;
}

- (void) dealloc
{
	[data release];
	[comments release];
	[name release];
	[super dealloc];
}

- (NSMutableData*) data
{
	return data;
}

- (void) setData: (NSMutableData*) newData
{
	if (data!=nil) [data release];
	data = newData;
	[data retain];
}

- (ASynth*) synth
{
	return synth;
}

- (void) setSynth: (ASynth*) newSynth
{
	synth = newSynth;
}

- (NSString*) comments
{
	return comments;
}

- (void) setComments: (NSString*) newComments
{
	[comments release];
	comments = [[NSString alloc] initWithString: newComments];
}	

@end
