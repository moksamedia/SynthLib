//
//  AProgram.m
//  SynthLib
//
//  Created by Andrew Hughes on 11/27/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AProgram.h"
#import "SynthFactory.h"
#import "SynthLib.h"


@implementation AProgram

//////////////////////////////////////////////////////////////////////////////////////////////////
// SAVE AND LOAD

- (void) encodeWithCoder: (NSCoder *) coder
{
	[coder encodeObject: data forKey:@"data"];
	[coder encodeObject: name forKey:@"name"];
	[coder encodeObject: comments forKey:@"comments"];
	
	[coder encodeInt: programNumber forKey:@"programNumber"];
	[coder encodeInt: bankNumber forKey:@"bankNumber"];
	
	[coder encodeInt: [synth inputPort] forKey:@"inPort"];
	[coder encodeInt: [synth outputPort] forKey:@"outPort"];
	
	return;
}

- (id)initWithCoder: (NSCoder *) coder
{
	data = [[coder decodeObjectForKey:@"data"] retain];
	name = [[coder decodeObjectForKey:@"name"] retain];
	//synth = [[coder decodeObjectForKey:@"synth"] retain];
	//if (synth == nil) 
	synth = [[SynthFactory sharedSynthFactory] getSynth: SYNTH_ANDROMEDA inPort: [coder decodeIntForKey:@"inPort"] outPort: [coder decodeIntForKey:@"outPort"]];	
	comments = [[coder decodeObjectForKey:@"comments"] retain];
	
	NSAssert(data != nil && name != nil && synth != nil && comments != nil, @"nil value on load!");
	
	bankNumber = [coder decodeIntForKey:@"bankNumber"];
	programNumber = [coder decodeIntForKey:@"programNumber"];
	
	return self;
}

@end
