//
//  MyDocument.h
//  SynthLib
//
//  Created by Andrew Hughes on 11/23/08.
//  Copyright __MyCompanyName__ 2008 . All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <CoreMidi/MidiServices.h>
#import "Midi.h"
#import "ASynth.h"
#import "TableDataSource.h"
#import "ACollection.h"

enum
{
	SYNTH_ANDROMEDA = 0,
	SYNTH_MOOG = 1,
	SYNTH_PCM91 = 2,
	SYNTH_WALDORFQ = 3,
	SYNTH_SUPERNOVA = 4
};

// drag and drop data type
#define SynthProgramTableViewDataType @"SynthProgramTableViewDataType"


@interface SynthLib : NSDocument
{
	ASynth * andromeda;
	ASynth* pcm91;
	TableDataSource * tableDataSource;
	ACollection * mainCollection;	// main data sturcture: holds the synth programs (patches) that are shown in the table view
	
	NSUndoManager * undoManager;
	
	NSNumberFormatter * numberFormatter;
	
	BOOL loadFromFileFlag;

	IBOutlet NSTableView * tableView;	// main table view in window
	IBOutlet NSComboBox * andromedaBankSelectComboBox; // for get button
	IBOutlet NSComboBox * andromedaProgramSelectComboBox; // for get button
	IBOutlet NSComboBox * andromedaSendProgramSelectComboBox;  // for send button

	IBOutlet NSComboBox * pcm91SendBankSelectComboBox;
	IBOutlet NSComboBox * pcm91BankSelectComboBox; // for get button
	IBOutlet NSComboBox * pcm91ProgramSelectComboBox; // for get button
	IBOutlet NSComboBox * pcm91SendProgramSelectComboBox;  // for send button
	
	IBOutlet NSTabView * synthSelectTabView;	// tabless tabbed view used swap between controls for diff synths
	
	IBOutlet NSComboBox * synthSelectComboBox;
	IBOutlet NSButton * filterTableActiveSynthCheckBox; // when checked, the table view is filtered by the active synth (ie, only shows programs of the active synth)
}

// UTILITY FUNCTIONS
- (NSArray*) getItemsSelectedInTableView;
- (BOOL) checkNoSelectionWithMessage: (NSString*) message;
- (void) addItemsToCollection: (NSArray*) itemsToAdd;

// ANDROMEDA FUNCTIONS
- (IBAction) andromedaGetProgram: (id) sender;	// gets a program from the synth
- (IBAction) andromedaGetProgramEditBuffer: (id) sender;  // short cut to get the edit buffer from the synth
- (IBAction) andromedaSendProgram: (id) sender;  // sends a program to the synth, can select edit buffer
- (IBAction) andromedaGetProgramSelectComboBoxChange: (id) sender;
- (IBAction) andromedaSendProgramSelectComboBoxChange: (id) sender;

// PCM91 FUNCTIONS
- (IBAction) pcm91GetProgram: (id) sender;
- (IBAction) pcm91GetProgramEditBuffer: (id) sender;  // short cut to get the edit buffer from the synth
- (IBAction) pcm91SendProgram: (id) sender;  // sends a program to the synth, can select edit buffer
- (IBAction) pcm91GetProgramSelectComboBoxChange: (id) sender;
- (IBAction) pcm91SendProgramSelectComboBoxChange: (id) sender;
- (IBAction) pcm91GetProgramEditBuffer: (id) sender;

// ACTIVE SYNTH FUNCTIONS
- (IBAction) activeSynthDidChange: (id) sender;
- (ASynth*) activeSynth;
- (IBAction) activeSynthFilterButtonClicked: (id) sender;

// EXPORT AND IMPORT SYSEX FILES
- (IBAction) exportFilesToSysex: (id) sender;
- (IBAction) importFilesFromSysex: (id) sender;

- (IBAction) deleteSelectedItems: (id) sender;
- (NSArray*) getItemsAndUnfiliteredRowsOfSelectedItemsInTableView;  // returns an array of ItemsAndRows of selected items with a selected item and its UNFILTERED index in the mainCollection (for undo operations)
- (NSArray*) getItemsSelectedInTableView;
- (void) addItemsToCollection: (NSArray*) itemsToAdd atFilteredIndex: (int) index;
- (void) deleteItems: (NSArray*) itemsToDelete;

@end
