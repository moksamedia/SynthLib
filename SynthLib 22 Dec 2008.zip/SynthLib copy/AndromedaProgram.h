//
//  AndromedaProgram.h
//  SynthLib
//
//  Created by Andrew Hughes on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "AProgram.h"


@interface AndromedaProgram : AProgram 
{

}

- (NSString*) name;
- (void) setName: (NSString*) newName;

// translate to and from 'packed' data format for A6
- (Byte) getByteFromData: (int) index;
- (void) writeByteToData: (Byte) byte atIndex: (int) index;
- (void) extractNameFromDataAndSetToName;
- (void) setNameToData;



@end
