//
//  AProgram.h
//  SynthLib
//
//  Created by Andrew Hughes on 11/27/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ASynth.h"
#import "ACollectionItem.h"

@interface AProgram : ACollectionItem
{
	int programNumber, bankNumber;
}

- (int) bankNumber;
- (void) setBankNumber: (int) i;
- (BOOL) trySetBankNumber: (int) i;

- (int) programNumber;
- (void) setProgramNumber: (int) i;
- (BOOL) trySetProgramNumber: (int) i;


@end
