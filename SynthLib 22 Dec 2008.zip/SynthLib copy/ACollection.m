//
//  Collection.m
//  SynthLib
//
//  Created by Andrew Hughes on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "ACollection.h"
#import "AProgram.h"

@implementation ACollection

- (id) initForTableView: (NSTableView*) tb
{
	if ((self = [super init])) 
	{
		theCollection = [[NSMutableArray alloc] init];
		filteredCollection = [[NSMutableArray alloc] init];
		tableView = tb;
		
		// Number formatter used to parse program numbers entered into the table view
		numberFormatter = [[NSNumberFormatter alloc] init];
		[numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
		[numberFormatter setFormat:@"0"];
		
		activeSynthForFilter = nil;

	}
	
	return self;
}

- (void) dealloc
{
	[theCollection release];
	[filteredCollection release];
	[super dealloc];
}

- (void) encodeWithCoder: (NSCoder *) coder
{
	[coder encodeObject: theCollection forKey:@"theCollection"];
	return;
}

- (id) initWithCoder: (NSCoder *) coder
{
	theCollection = [[coder decodeObjectForKey:@"theCollection"] retain];

	// Number formatter used to parse program numbers entered into the table view
	numberFormatter = [[NSNumberFormatter alloc] init];
	[numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
	[numberFormatter setFormat:@"0"];

	filteredCollection = [[NSMutableArray alloc] initWithArray: theCollection];

	return self;
}


// sets the associated table view
- (void) setTableView: (NSTableView*) tb
{
	tableView = tb;
}

// the array that holds the programs
- (NSMutableArray*) theCollection
{
	return theCollection;
}

// add an item
- (void) addItem: (id) newItem
{
	NSAssert([newItem isKindOfClass:[AProgram class]], @"ACollection: addItem: trying to add item that is not AProgram");
	[theCollection addObject:newItem];
	[self updateFilteredCollection];
	[tableView reloadData];
}

- (void) addItems: (NSArray*) newItems
{
	int i;
	for (i=0; i<[newItems count]; i++)
	{
		[self addItem:[newItems objectAtIndex:i]];
	}
}

// add an item inserted at the row selected in the table view
- (void) addItemAtSelectedRow: (id) newItem
{
	int selectedRow = [tableView selectedRow];
	if (selectedRow < 0) selectedRow = [theCollection count];
	NSAssert([newItem isKindOfClass:[AProgram class]], @"ACollection: addItemAtSelectedRow: trying to add item that is not AProgram");
	[theCollection insertObject:newItem atIndex:selectedRow];
	NSLog(@"adding new item %@ at row %d", [newItem name], selectedRow);
	[self updateFilteredCollection];
	[tableView reloadData];
}

// returns a specific item
- (id) getItem: (int) i
{
	NSAssert (i >=0 && i < [theCollection count], @"ACollection: getItem - out of bounds!");
	return [theCollection objectAtIndex: i];
}

- (int) numberOfItems
{
	return [theCollection count];
}

- (void) insertItems: (NSArray*) newItems atUnfilteredIndex: (int) i
{
	//if (i < 1) i=1;
	
	int j;
	for (j=0; j < [newItems count]; j++)
	{
		NSLog(@"Inserting %@ to collection", [[newItems objectAtIndex:j] name]);
		[theCollection insertObject: [newItems objectAtIndex:j] atIndex: i];
	}
	[self updateFilteredCollection];
}

- (void) insertItem: (id) newItem atUnfilteredIndex: (int) index
{
	NSAssert(index <= [theCollection count], @"index out of bounds!");
	[theCollection insertObject: newItem atIndex: index];
	[self updateFilteredCollection];
}

- (void) removeItems: (NSArray*) itemsToRemove
{
	int j;
	for (j=0; j < [itemsToRemove count]; j++)
	{
		NSLog(@"Removing %@ from collection", [[itemsToRemove objectAtIndex:j] name]);
		[theCollection removeObject: [itemsToRemove objectAtIndex:j] ];
	}
	[self updateFilteredCollection];
}

- (int) unfilteredIndexOfItem: (id) item
{
	return [theCollection indexOfObject: item];
}

- (int) unfilteredIndexForFilteredIndex: (int) i
{
	if (i == -1 || i == 0) return 0;
	
	if (i == [filteredCollection count]) i = [filteredCollection count]-1;
	
	NSAssert(i>=0 && i < [filteredCollection count], @"index out of bounds!");
	return [theCollection indexOfObject: [filteredCollection objectAtIndex:i]];
}

///////////////////////////////////////////////////////////////////////////////////////////////////////
// FILTERED ACCESS ROUTINES FOR TABLE VIEW

// returns a specific item from the filtered array
- (id) getFilteredItem: (int) i
{
	NSAssert (i >=0 && i < [filteredCollection count], @"getFilteredItem - out of bounds!");
	return [filteredCollection objectAtIndex: i];
}

- (int) numberOfFilteredItems
{
	return [filteredCollection count];

}

- (void) setSynthFilterForTableView: (id) activeSynth
{
	activeSynthForFilter = activeSynth;
	[self updateFilteredCollection];
}

- (void) updateFilteredCollection
{
	[filteredCollection removeAllObjects];
	
	AProgram * prog;
	
	if (activeSynthForFilter == nil) 
	{
		[filteredCollection addObjectsFromArray: theCollection];
		return;
	}
	
	int i;
	for (i=0; i < [theCollection count]; i++)
	{
		prog = [theCollection objectAtIndex: i];
		if ([[prog synth] isKindOfClass: [activeSynthForFilter class]]) [filteredCollection addObject: prog];
	} 
}	

///////////////////////////////////////////////////////////////////////////////////////////////////////
// TABLE DATA SOURCE GET AND SET HOOK ROUTINES

// query method called by table view data source to get the string value for a given column (identifier) and row
- (NSString *) stringForIdentifier: (NSString*) identifier row: (int) rowIndex
{
	NSAssert(rowIndex >= 0 && rowIndex < [theCollection count], @"rowIndex out of bounds!");
	

	if ([identifier isEqualToString: @"Name"])
	{
		return [[self getFilteredItem: rowIndex] name];	
	}
	else if ([identifier isEqualToString: @"Prog"])
	{
		return [NSString stringWithFormat: @"%d", [(AProgram*)[self getFilteredItem: rowIndex] programNumber]];	
	}
	else if ([identifier isEqualToString: @"Bank"])
	{
		return [(AProgram*)[self getFilteredItem: rowIndex] bankName];
	}
	else if ([identifier isEqualToString: @"Synth"])
	{
		return [(AProgram*)[self getFilteredItem: rowIndex] synthName];
	}
	else if ([identifier isEqualToString: @"Comments"])
	{
		return [(AProgram*)[self getFilteredItem: rowIndex] comments];	
	}
	else
		return @"DOH!";

}

// method called by table view data source to set value for a given column (identifier) and row
// objectValue is assumed to be an NSString
- (NSString *) setValueForIdentifier: (NSString*) identifier row: (int) rowIndex objectValue: (id) anObject
{
	NSAssert(rowIndex >= 0 && rowIndex < [theCollection count], @"rowIndex out of bounds!");
	
	// NAME
	if ([identifier isEqualToString: @"Name"])
	{
		[(AProgram*)[self getFilteredItem: rowIndex] setName: anObject];
	}
	// PROGRAM NUMBER
	else if ([identifier isEqualToString: @"Prog"])
	{
		NSNumber * number = [numberFormatter numberFromString: anObject];
		[(AProgram*)[self getFilteredItem: rowIndex] trySetProgramNumber: [number intValue] ];
	}
	// BANK NUMBER
	else if ([identifier isEqualToString: @"Bank"])
	{
		NSNumber * number = [numberFormatter numberFromString: anObject];
		[(AProgram*)[self getFilteredItem: rowIndex] trySetBankNumber: [number intValue] ];
	}
	// COMMENTS
	else if ([identifier isEqualToString: @"Comments"])
	{
		[[self getFilteredItem: rowIndex] setComments: anObject];
	}
}


@end
