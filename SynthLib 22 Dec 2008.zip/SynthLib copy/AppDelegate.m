//
//  AppDelegate.m
//  StoryWriter
//
//  Created by Andrew Hughes on 12/30/07.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"
#import "SynthFactory.h"


@implementation AppDelegate

- (void)applicationWillTerminate:(NSNotification *)aNotification
{
	[[SynthFactory sharedSynthFactory] terminate];
}

@end
