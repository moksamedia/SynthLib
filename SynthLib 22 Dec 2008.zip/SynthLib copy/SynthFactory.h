//
//  SynthFactory.h
//  SynthLib
//
//  Created by Andrew Hughes on 12/18/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface SynthFactory : NSObject 
{
	NSMutableArray * synths;
}
+ (SynthFactory*)sharedSynthFactory;

- (id) getSynth: (int) synthType inPort: (int) inPort outPort: (int) outPort;
- (void) terminate;

@end
