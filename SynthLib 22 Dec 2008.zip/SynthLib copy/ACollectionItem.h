//
//  ACollectionItem.h
//  SynthLib
//
//  Created by Andrew Hughes on 12/20/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ASynth.h"

// for Collection Item type information
enum
{
		PROGRAM = 0
};

@interface ACollectionItem : NSObject 
{

	NSMutableData * data;
	ASynth * synth;
	NSString * comments;
	NSString * name;
	int type;
}

- (id) initWithSynth: (ASynth*) _synth data: (NSMutableData *) data type: (int) type;

- (NSString*) name;
- (void) setName: (NSString*) newName;

- (NSString*) comments;
- (void) setComments: (NSString*) newComments;

- (NSMutableData*) data;
- (void) setData: (NSMutableData*) newData;

- (ASynth*) synth;
- (void) setSynth: (ASynth*) newSynth;

- (NSString*) synthName;

- (id) copy;
- (id) copyWithZone: (NSZone*) zone;
- (id) mutableCopy;
- (id) mutableCopyWithZone: (NSZone*) zone;

@end
