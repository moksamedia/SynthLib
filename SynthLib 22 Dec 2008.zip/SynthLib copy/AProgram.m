//
//  AProgram.m
//  SynthLib
//
//  Created by Andrew Hughes on 11/27/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "AProgram.h"


@implementation AProgram


@end
