//
//  TableDataSource.m
//  SynthLib
//
//  Created by Andrew Hughes on 12/16/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "TableDataSource.h"
#import "ACollection.h"
#import "AProgram.h"
#import "SynthLib.h"
#import "Utility.h"

// aTableView's delegate is the object for which the data source should look up the information - this allows to use one data source for
// multiple table views and model objects (collections of programs)

@implementation TableDataSource

- (id) initWithDocument: (id) _document
{
	if ((self = [super init])) 
	{
		document = _document;
	}
	
	return self;

}

// this is used by the undo architecture to access the data source's document to make changes to the collection
- (id) document
{
	return document;
}

// Asks the data structure (the collection) for the display values for a given column and row
- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex
{
	ACollection * collection = [aTableView delegate];
	
	return [collection stringForIdentifier: [aTableColumn identifier] row:rowIndex];
}

// Allows user to edit cells in the table view and have those edits propogated to the data
- (void)tableView:(NSTableView *)aTableView setObjectValue:anObject forTableColumn:(NSTableColumn *)aTableColumn row:(int)rowIndex
{
	ACollection * collection = [aTableView delegate];

	[collection setValueForIdentifier: [aTableColumn identifier] row: rowIndex objectValue: anObject];
}

// returns the number of rows in the view, ie. the number of items in the collection of programs
- (int)numberOfRowsInTableView:(NSTableView *)aTableView
{
	return [[aTableView delegate] numberOfFilteredItems];
}

/*
	SORTING
	
	This uses the NSArray's sort function to sort the collection according to an array of descriptor.  The items in the array must
	have properties that are key-value coding compliant to match the descriptors.  For example, if sort by descriptor "name", then
	the items in the collection must respond to [item name], etc...
	
	The descriptors for each column are set in Interface Builder in the inspector window.
 */
- (void)tableView:(NSTableView *)aTableView sortDescriptorsDidChange:(NSArray *)oldDescriptors
{
	NSArray *newDescriptors = [aTableView sortDescriptors];
    [[[aTableView delegate] theCollection] sortUsingDescriptors:newDescriptors];
	[[aTableView delegate] updateFilteredCollection];
    [aTableView reloadData];
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// DRAG AND DROP 


- (BOOL)tableView:(NSTableView *)tv writeRowsWithIndexes:(NSIndexSet *)rowIndexes toPasteboard:(NSPasteboard*)pboard
{

	// get the collection from the table view
	ACollection * collection = [tv delegate];

	// ridiculously complicated way to get the indexes of the selected rows from the index set
	unsigned int maxSizeOfIndexSet = [tv numberOfRows];
	unsigned int buffer[maxSizeOfIndexSet];	// buffer into which the selected rows will be copied
	int numberOfIndexes;
	NSRange range = NSMakeRange(0, maxSizeOfIndexSet);
	NSRangePointer rangePointer = &range;
	numberOfIndexes = [rowIndexes getIndexes: buffer maxCount: maxSizeOfIndexSet inIndexRange: rangePointer];

	// Array to hold the selected items
	NSMutableArray * selectedItems = [[NSMutableArray alloc] init];

	// iterate through the selected rows and add the selected objects to selectedItems array
	int i;		
	for (i=0; i<numberOfIndexes; i++)
	{	
		[selectedItems addObject: [collection getFilteredItem: buffer[i] ] ];
	}
	
	NSLog(@"Copying %d items, %d", [selectedItems count], [rowIndexes count]);
	
	// give the selected items to my Utility pasteboard server
	[Utility StartDragWithSource: tv items: selectedItems];
	[selectedItems release];  // utility retains, to release
	
	// still have to do this even though we're using our own pasteboard
    [pboard declareTypes:[NSArray arrayWithObject:SynthProgramTableViewDataType] owner:self];
    [pboard setData:nil forType:SynthProgramTableViewDataType];
   
	 return YES;
}

- (NSDragOperation)tableView:(NSTableView*)tv validateDrop:(id <NSDraggingInfo>)info proposedRow:(int)row proposedDropOperation:(NSTableViewDropOperation)op
{
    // Add code here to validate the drop
    NSLog(@"validate Drop at Row %d", row);
    return NSDragOperationEvery;
}

- (BOOL)tableView:(NSTableView *)aTableView acceptDrop:(id <NSDraggingInfo>)info row:(int)row dropOperation:(NSTableViewDropOperation)operation
{
	BOOL commandKeyDown = (([[NSApp currentEvent] modifierFlags] & NSCommandKeyMask) == NSCommandKeyMask);
	
	// if the command key is NOT down, then we want to MOVE the items, so remove them from the original collection.  otherwise, leave them in place and copy.
	// MOVE
	if (!commandKeyDown)
	{
		// remove the dragged items from the original table view
		//[[[Utility GetDragSource] delegate] removeItems: [Utility GetDragItems]];
		[[[[Utility GetDragSource] dataSource] document] deleteItems: [Utility GetDragItems]];
		//[[[Utility GetDragSource] delegate] updateFilteredCollection];
	}
	// insert them into the target table view
	//[[aTableView delegate] insertItems: [Utility GetDragItems] atIndex: row];

	//if (row == -1) row = 0;
	NSLog(@"adding items at row %d", row);
	
	[[[aTableView dataSource] document] addItemsToCollection: [Utility GetDragItems] atFilteredIndex: row];
	
	// reload the data
	[[Utility GetDragSource] reloadData];
	if (aTableView != [Utility GetDragSource]) [aTableView reloadData];

	// this cleard the pasteboard and releases the array of drag items
	//[Utility EndDrag];
	return TRUE;
}

@end
