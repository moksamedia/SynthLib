//
//  ASynth.h
//  SynthLib
//
//  Created by Andrew Hughes on 11/24/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Midi.h"
#import "ACollection.h"

/*
	Data:
		Port, Channel, DeviceID
	
	Functions:
		Request Patch Dump
		Request Bank Dump
		Send Patch
		Send Patches
		Send Bank
		

*/


@interface ASynth : NSObject {

	int inputPort, outputPort, deviceID;
	
	// The midi object associated with the synth, created by the synth object using the port data
	Midi * midi;
	
	// The collection for which the current incoming sysex data is intended for.  Passed in
	// when a sysex request is made
	ACollection * requestingCollection;

}

- (id) initWithInputPort: (int) _inputPort outputPort: (int) _outputPort;
- (BOOL) createMidi;

- (void) receiveSysexMessage: (NSData *) data;
- (BOOL) checkMatchForSynthFactory: (int) synthType inPort: (int) inPort outPort: (int) outPort;
- (NSData*) prepareProgramToSend: (id) program programNumber: (int) programNumber bankNumber: (int) bankNumber;
- (NSString*) name;

- (BOOL) tryImportData: (NSData*) dataToImport forCollection: (ACollection*) collection;
@end
